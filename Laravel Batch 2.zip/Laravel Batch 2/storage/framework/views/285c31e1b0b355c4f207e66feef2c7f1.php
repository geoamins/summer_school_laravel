<!doctype html>
<html class="modern fixed has-top-menu has-left-sidebar-half" data-style-switcher-options="{'changeLogo': false}">

<head>

    <!-- Basic -->
    <meta charset="UTF-8">

    <title>Dashboard | Admin</title>

    <meta name="keywords" content="HTML5 Admin Template" />
    <meta name="description" content="Porto Admin - Responsive HTML5 Template">
    <meta name="author" content="okler.net">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Web Fonts  -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,300,400,600,700,800,900" rel="stylesheet"
        type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/bootstrap/css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/animate/animate.compat.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/boxicons/css/boxicons.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/magnific-popup/magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css')); ?>" />

    <!-- Specific Page Vendor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/morris/morris.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/datatables/media/css/dataTables.bootstrap5.css')); ?>" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/theme.css')); ?>" />

    <!-- Theme Layout -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/layouts/modern.css')); ?>" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/custom.css')); ?>">

    <!-- Head Libs -->
    <script src="<?php echo e(asset('dashboard/vendor/modernizr/modernizr.js')); ?>"></script>

    <script src="<?php echo e(asset('dashboard/master/style-switcher/style.switcher.localstorage.js')); ?>"></script>

</head>

<body>
    <section class="body">

        <!-- start: header -->
        <header class="header header-nav-menu header-nav-links">
            <div class="logo-container">
                <a href="" class="logo">
                    <p style="font-weight: bold; color: white; font-size: 22px">Admin Panel</p>
                </a>
                <button class="btn header-btn-collapse-nav d-lg-none" data-bs-toggle="collapse"
                    data-bs-target=".header-nav">
                    <i class="fas fa-bars"></i>
                </button>

                <!-- start: header nav menu -->
                <div class="header-nav collapse">
                    <div
                        class="header-nav-main header-nav-main-effect-1 header-nav-main-sub-effect-1 header-nav-main-square">
                        <nav>
                            <ul class="nav nav-pills" id="mainNav">
                                <li class="">
                                    
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <!-- end: header nav menu -->
            </div>

            <!-- start: search & user box -->
            <div class="header-right">

                <a class="btn search-toggle d-none d-md-inline-block d-xl-none" data-toggle-class="active"
                    data-target=".search"><i class="bx bx-search"></i></a>
                <form action="https://www.okler.net/previews/porto-admin/4.2.0/pages-search-results.html"
                    class="search search-style-1 nav-form d-none d-xl-inline-block">
                    <div class="input-group">
                        <input type="text" class="form-control" name="q" id="q"
                            placeholder="Search...">
                        <button class="btn btn-default" type="submit"><i class="bx bx-search"></i></button>
                    </div>
                </form>
                <span class="separator"></span>

                <div id="userbox" class="userbox">
                    <?php if(auth()->check()): ?>
                    <a href="#" data-bs-toggle="dropdown">

                        <span class="profile-picture profile-picture-as-text"><?php echo e(substr(auth()->user()->name, 0, 1)); ?></span>
                        <div class="profile-info profile-info-no-role" data-lock-name="<?php echo e(auth()->user()->name); ?>"
                            data-lock-email="<?php echo e(auth()->user()->email); ?>">
                            <span class="name">Hi, <strong class="font-weight-semibold"><?php echo e(auth()->user()->name); ?></strong></span>
                        </div>

                        <i class="fas fa-chevron-down text-color-dark"></i>
                    </a>
                    <?php endif; ?>


                    <div class="dropdown-menu">
                        <ul class="list-unstyled">
                            <li>
                                <a role="menuitem" tabindex="-1" href="pages-user-profile.html"><i
                                        class="bx bx-user"></i> My Profile</a>
                            </li>
                            <li>
                                <a role="menuitem" tabindex="-1" href="#" data-lock-screen="true"><i
                                        class="bx bx-lock-open-alt"></i> Lock Screen</a>
                            </li>
                            <?php if(auth()->guard()->check()): ?>
                                <li>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button role="menuitem" tabindex="-1" type="submit" class="btn"><i
                                                class="bx bx-log-out"></i>
                                            Logout</button>
                                    </form>
                                </li>


                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- end: search & user box -->
        </header>
        <!-- end: header -->

        <div class="inner-wrapper">
            <!-- start: sidebar -->
            <aside id="sidebar-left" class="sidebar-left">

                <div class="sidebar-header">
                    <div class="sidebar-toggle d-none d-md-flex" data-toggle-class="sidebar-left-collapsed"
                        data-target="html" data-fire-event="sidebar-left-toggle">
                        <i class="fas fa-bars" aria-label="Toggle sidebar"></i>
                    </div>
                </div>

                <div class="nano">
                    <div class="nano-content">
                        <nav id="menu" class="nav-main" role="navigation">
                            <ul class="nav nav-main">
                                <li class=" <?php echo e(isset($menu) ? ($menu == 'Dashboard' ? 'nav-active' : '') : ''); ?> ">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>" data-target="dashboard">
                                        <i class="bx bx-home-alt" aria-hidden="true"></i>
                                        <span>Dashboard</span>
                                    </a>
                                </li>
                                <li
                                    class="nav-parent <?php echo e(isset($menu) ? ($menu == 'usermanagement' ? 'nav-expanded nav-active' : '') : ''); ?>">
                                    <a class="nav-link" href="#">
                                        <i class="bx bx-user" aria-hidden="true"></i>
                                        <span>User Management</span>
                                    </a>
                                    <ul class="nav nav-children">
                                        <li
                                            class="<?php echo e(isset($submenu) ? ($submenu == 'user' ? 'nav-active' : '') : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
                                                Users
                                            </a>
                                        </li>
                                        <li
                                            class="<?php echo e(isset($submenu) ? ($submenu == 'role' ? 'nav-active' : '') : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('roles.index')); ?>">
                                                Roles
                                            </a>
                                        </li>
                                        <li
                                            class="<?php echo e(isset($submenu) ? ($submenu == 'permission' ? 'nav-active' : '') : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('permissions.index')); ?>">
                                                Permission
                                            </a>
                                        </li>
                                    </ul>
                                </li>

                            </ul>
                        </nav>


                        <hr class="separator" />

                    </div>

                    <script>
                        // Maintain Scroll Position
                        if (typeof localStorage !== 'undefined') {
                            if (localStorage.getItem('sidebar-left-position') !== null) {
                                var initialPosition = localStorage.getItem('sidebar-left-position'),
                                    sidebarLeft = document.querySelector('#sidebar-left .nano-content');

                                sidebarLeft.scrollTop = initialPosition;
                            }
                        }
                    </script>

                </div>

            </aside>
            <!-- end: sidebar -->

            <section role="main" class="content-body content-body-modern" style="margin-top: 0px">


                <!-- start: page -->
                <?php echo $__env->yieldContent('contents'); ?>

                <!-- end: page -->
            </section>
        </div>

    </section>

    <!-- Vendor -->
    <script src="<?php echo e(asset('dashboard/vendor/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/jquery-browser-mobile/jquery.browser.mobile.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/jquery-cookie/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/master/style-switcher/style.switcher.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/popper/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/common/common.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/nanoscroller/nanoscroller.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/magnific-popup/jquery.magnific-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/jquery-placeholder/jquery.placeholder.js')); ?>"></script>

    <!-- Specific Page Vendor -->
    <script src="<?php echo e(asset('dashboard/vendor/raphael/raphael.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/morris/morris.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/vendor/datatables/media/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <!-- Theme Base, Components and Settings -->
    <script src="<?php echo e(asset('dashboard/js/theme.js')); ?>"></script>

    <!-- Theme Custom -->
    <script src="<?php echo e(asset('dashboard/js/custom.js')); ?>"></script>

    <!-- Theme Initialization Files -->
    <script src="<?php echo e(asset('dashboard/js/theme.init.js')); ?>"></script>

    <!-- Examples -->
    <script src="<?php echo e(asset('dashboard/js/examples/examples.header.menu.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/examples/examples.ecommerce.dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/js/examples/examples.ecommerce.datatables.list.js')); ?>"></script>

</body>
</html>
<?php /**PATH /Users/rizwansarwar/Desktop/Laravel-Projects/setup porto/resources/views/admin/adminmain.blade.php ENDPATH**/ ?>