<!doctype html>
<html class="fixed">
<head>

		<!-- Basic -->
		<meta charset="UTF-8">

		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/bootstrap/css/bootstrap.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/animate/animate.compat.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/font-awesome/css/all.min.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/boxicons/css/boxicons.min.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/magnific-popup/magnific-popup.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css')); ?>" />

		<!-- Specific Page Vendor CSS -->


		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/css/theme.css')); ?>" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('dashboard/css/custom.css')); ?>">

		<!-- Head Libs -->
		<script src="<?php echo e(asset('dashboard/vendor/modernizr/modernizr.js')); ?>"></script>

		<script src="<?php echo e(asset('dashboard/master/style-switcher/style.switcher.localstorage.js')); ?>"></script>

	</head>
	<body>
		<!-- start: page -->
		<section class="body-sign">
			<div class="center-sign">
				<a href="https://www.okler.net/" class="logo float-start">
				<h2 style="color: black"><strong>Admin Login</strong></h2>
				</a>

				<div class="panel card-sign">
					<div class="card-title-sign mt-3 text-end">
						<h2 class="title text-uppercase font-weight-bold m-0"><i class="bx bx-user-circle me-1 text-6 position-relative top-5"></i> Sign In</h2>
					</div>
					<div class="card-body">
						<form action="<?php echo e(route('login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
							<div class="form-group mb-3">
								<label>Username</label>
								<div class="input-group">
									<input name="email" type="text" class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

								</div>
							</div>

							<div class="form-group mb-3">
								<div class="clearfix">
									<label class="float-start">Password</label>
									<a href="pages-recover-password.html" class="float-end">Lost Password?</a>
								</div>
								<div class="input-group">
									<input name="password" type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"" />
									<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
							</div>

							<div class="row">
								<div class="col-sm-8">
									<div class="checkbox-custom checkbox-default">
										<input id="RememberMe" name="rememberme" type="checkbox"/>
										<label for="RememberMe">Remember Me</label>
									</div>
								</div>
								<div class="col-sm-4 text-end">
									<button type="submit" class="btn btn-secondary mt-2">Sign In</button>
								</div>
							</div>
							<span class="mt-3 mb-3 line-thru text-center text-uppercase">
								<span>or</span>
							</span>



							<p class="text-center">Developed by <a href="rizwansarwar.me">Rizwan Sarwar</a></p>

						</form>
					</div>
				</div>
			</div>
		</section>
		<!-- end: page -->

		<!-- Vendor -->
		<script src="<?php echo e(asset('dashboard/vendor/jquery/jquery.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/jquery-browser-mobile/jquery.browser.mobile.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/jquery-cookie/jquery.cookie.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/master/style-switcher/style.switcher.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/popper/umd/popper.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/common/common.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/nanoscroller/nanoscroller.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/magnific-popup/jquery.magnific-popup.js')); ?>"></script>
		<script src="<?php echo e(asset('dashboard/vendor/jquery-placeholder/jquery.placeholder.js')); ?>"></script>

		<!-- Specific Page Vendor -->


		<!-- Theme Base, Components and Settings -->
		<script src="<?php echo e(asset('dashboard/js/theme.js')); ?>"></script>

		<!-- Theme Custom -->
		<script src="<?php echo e(asset('dashboard/js/custom.js')); ?>"></script>

		<!-- Theme Initialization Files -->
		<script src="<?php echo e(asset('dashboard/js/theme.init.js')); ?>"></script>

	</body>
</html>
<?php /**PATH /Users/rizwansarwar/Desktop/Laravel-Projects/setup porto/resources/views/auth/login.blade.php ENDPATH**/ ?>